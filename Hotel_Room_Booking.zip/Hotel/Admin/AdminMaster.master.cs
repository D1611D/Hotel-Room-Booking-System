﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AdminMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["cid"] != null)
        {
            LinkButton1.Visible = true;

            //HyperLink8.Visible = false; //4 customer login
            //HyperLink2.Visible = false;
            //HyperLink3.Visible = false;
        }
        else if (Session["adminid"] != null)
        {
            LinkButton1.Visible = true;

            //HyperLink2.Visible = true;//check in 
            //HyperLink3.Visible = true;//check out
            //HyperLink8.Visible = false;//4 customer login
        }
        else
        {
            // LinkButton1.Visible = false;

            //HyperLink2.Visible = false;
            //HyperLink3.Visible = false;
            //HyperLink8.Visible = true;
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        LinkButton1.Visible = false;
        string s11 = "";

        if (Session["cid"] == null)
        {
            s11 = "../index.aspx";
        }
        else if (Session["adminid"] == null)
        {
            s11 = "index.aspx";
        }
        Session.RemoveAll();
        Response.Redirect(s11);

    }
}
