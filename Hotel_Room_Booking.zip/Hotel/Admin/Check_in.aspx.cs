﻿//using System;
//using System.Collections;
//using System.Configuration;
//using System.Data;
//using System.Linq;
//using System.Web;
//using System.Web.Security;
//using System.Web.UI;
//using System.Web.UI.HtmlControls;
//using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;
//using System.Data.SqlClient;

//public partial class Check_in : System.Web.UI.Page
//{
//    SqlConnection conn;
//    SqlCommand cmd;
//    SqlDataReader dr;
//    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
//    protected void Page_Load(object sender, EventArgs e)
//    {
      
//        if (Session["adminid"] != null)
//        {
//            TextBox2.Text = Session["adminnm"].ToString();
//        }
//        else
//        {
//            Response.Write("<script type=text/javascript>alert('You Must Have To Login...Please Login');</script>");
//            Response.Redirect("~/login.aspx");
//        }

//        //DateTime.Now.ToString("HH:mm:ss tt");

//        //Page.Header.Title="Check In";

//        //Display current LONG date in textbox
//        if(!Page.IsPostBack)
//            TextBox1.Text = DateTime.Now.ToString("D");

//        //this code is for HOUR dropdown list
//        int h1= Convert.ToInt32(DateTime.Now.ToString("HH"));
//        if (h1 > 12)
//            h1 = h1 - 12;

//        DropDownList1.Text = h1.ToString();


//        //this code is for MINUTE dropdown list
//        for (int i = 1; i <= 59; i++)
//        {
//            DropDownList2.Items.Add(i.ToString());
//        }
//        DropDownList2.Text= Convert.ToInt32(DateTime.Now.ToString("mm")).ToString();

//        //this code is for SECOND dropdown list
//        DropDownList3.Text = DateTime.Now.ToString("tt");

//        //to add register customer name in dropdown

//        //4 ROOM TYPE
//        if (!Page.IsPostBack)
//        {
//            //2 add room type to dropdown
//            conn = new SqlConnection(connStr);
//            conn.Open();

//            cmd = new SqlCommand("SELECT DISTINCT room_type FROM Room_Master", conn);
//            dr = cmd.ExecuteReader();

//            while (dr.Read())
//            {
//                DropDownList6.Items.Add(dr[0].ToString());
//            }
//            dr.Close();
//            conn.Close();
//        }
        
//    }
//    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
//    {
//        TextBox1.Text = Calendar1.SelectedDate.ToString("D");
//    }
//    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
//    {
//        if (e.Day.Date < System.DateTime.Today)
//        {
//            // Disable date
//            e.Day.IsSelectable = false;
//            // Change color of disabled date
//            e.Cell.ForeColor = System.Drawing.Color.Gray;
//            e.Cell.ToolTip = "This date is not available";
//        } 

//    }
//    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
//    {
//        if (RadioButton1.Checked == true)
//        {
//            DropDownList4.Items.Clear();
//            DropDownList4.Items.Add("<--Select Name-->");
//            conn = new SqlConnection(connStr);
//            conn.Open();

//            cmd = new SqlCommand("SELECT Customer_Id,cname FROM Adv_Booking WHERE Adv_Date='"+Convert.ToDateTime(TextBox1.Text)+"' AND check_in = 0", conn);
//            dr = cmd.ExecuteReader();

//            while (dr.Read())
//            {
//                DropDownList4.Items.Add(dr[0].ToString() + " - " + dr[1].ToString());
//            }
//            dr.Close();
//            conn.Close();   
//        }

//    }
//    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
//    {
//        if (RadioButton2.Checked == true)
//        {
//            DropDownList4.Items.Clear();
//            //Session["adminnm"]
//            DropDownList4.Items.Add("<--Select Name-->");
//            conn = new SqlConnection(connStr);
//            conn.Open();

//            cmd = new SqlCommand("SELECT Customer_Id,cname FROM Registration ORDER BY Customer_Id", conn);
//            dr = cmd.ExecuteReader();

//            while (dr.Read())
//            {
//                DropDownList4.Items.Add(dr[0].ToString() + " - " + dr[1].ToString());
//            }
//            dr.Close();
//            conn.Close();
//        }

//    }
//    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
//    {
//        if (RadioButton1.Checked == true)
//        {
//            string[] temp = new string[2];
//            temp = ((DropDownList4.Text).Split('-'));
//            //temp[0] = TextBox1.Text;
//            //temp[1] = TextBox2.Text;

//            conn = new SqlConnection(connStr);
//            conn.Open();

//            cmd = new SqlCommand("SELECT Room_type FROM Adv_Booking where Customer_Id ='"+temp[0].Trim()+"'", conn);
//            dr = cmd.ExecuteReader();

//            if(dr.Read())
//            {
//                DropDownList6.Text= dr[0].ToString();
//            }
//            dr.Close();
//            conn.Close();
//            if (DropDownList6.Text != "")
//            {
//                DropDownList5.Items.Clear();
//                conn = new SqlConnection(connStr);
//                conn.Open();

//                cmd = new SqlCommand("SELECT room_no FROM Room_Master where room_type ='" + DropDownList6.Text + "'", conn);
//                dr = cmd.ExecuteReader();

//                while (dr.Read())
//                {
//                    DropDownList5.Items.Add(dr[0].ToString());
//                }
//                dr.Close();
//                conn.Close();
//            }
//        }
//    }
//    protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
//    {
//        if (DropDownList6.Text != "")
//        {
//            DropDownList5.Items.Clear();
//            conn = new SqlConnection(connStr);
//            conn.Open();

//            cmd = new SqlCommand("SELECT room_no FROM Room_Master where room_type ='" + DropDownList6.Text+ "'", conn);
//            dr = cmd.ExecuteReader();

//            while(dr.Read())
//            {
//                DropDownList5.Items.Add(dr[0].ToString());
//            }
//            dr.Close();
//            conn.Close(); 
//        }
//    }
//    protected void Button1_Click(object sender, EventArgs e)
//    {
//        if (TextBox1.Text != "" && TextBox2.Text != "" && DropDownList4.Text != "<--Select Name-->" && DropDownList5.Text != "" && DropDownList6.Text != "" && TextBox4.Text != "")
//        {
//            string temp1 = "";
//            string[] temp2 = new string[2];

//            temp2 = (DropDownList4.Text).Split('-');

//            temp1 = DropDownList1.Text + ":" + DropDownList2.Text + " " + DropDownList3.Text;

//            conn = new SqlConnection(connStr);
//            conn.Open();

//            cmd = new SqlCommand("INSERT INTO Chk_In (chk_in_date,chk_in_time,Customer_Id,Room_No,No_of_Days,check_out) VALUES(@chk_in_date,@chk_in_time,@Customer_Id,@Room_No,@No_of_Days,@check_out)", conn);
//            cmd.Parameters.AddWithValue("@chk_in_date", Convert.ToDateTime(TextBox1.Text));
//            cmd.Parameters.AddWithValue("@chk_in_time", temp1);
//            cmd.Parameters.AddWithValue("@Customer_Id", temp2[0].Trim());
//            cmd.Parameters.AddWithValue("@Room_No", DropDownList5.Text);
//            cmd.Parameters.AddWithValue("@No_of_Days", TextBox4.Text);
//            cmd.Parameters.AddWithValue("@check_out", "0");

//            int rows = cmd.ExecuteNonQuery();
//            conn.Close();

//            //4 update adv_booking table
//            conn = new SqlConnection(connStr);
//            conn.Open();

//            cmd = new SqlCommand("UPDATE Adv_Booking SET check_in='1' WHERE Customer_Id = '" + temp2[0].Trim() + "' AND check_in = '0'", conn);

//            int rows1 = cmd.ExecuteNonQuery();
//            conn.Close();

//            Response.Redirect("adminhome.aspx");

            
//        }
//        else
//        {
//            Response.Write("<script type=text/javascript>alert('Enter necessary information');</script>");
//        }
//    }
//    protected void TextBox2_TextChanged(object sender, EventArgs e)
//    {

//    }
//}

using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Check_in : System.Web.UI.Page
{
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminid"] != null)
        {
            TextBox2.Text = Session["adminnm"].ToString();
        }
        else
        {
            Response.Write("<script>alert('You Must Have To Login... Please Login');</script>");
            Response.Redirect("~/login.aspx");
        }

        if (!Page.IsPostBack)
        {
            TextBox1.Text = DateTime.Now.ToString("D"); // Show current date

            // Set Hour dropdown
            int hour = DateTime.Now.Hour;
            if (hour > 12) hour -= 12;
            DropDownList1.Text = hour.ToString();

            // Set Minutes dropdown
            for (int i = 1; i <= 59; i++)
            {
                DropDownList2.Items.Add(i.ToString());
            }
            DropDownList2.Text = DateTime.Now.Minute.ToString();

            // Set AM/PM dropdown
            DropDownList3.Text = DateTime.Now.ToString("tt");

            // Load Room Types
            LoadRoomTypes();
        }
    }

    private void LoadRoomTypes()
    {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            conn.Open();
            using (SqlCommand cmd = new SqlCommand("SELECT DISTINCT room_type FROM Room_Master", conn))
            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    DropDownList6.Items.Add(dr[0].ToString());
                }
            }
        }
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToString("D");
    }

    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date < DateTime.Today)
        {
            e.Day.IsSelectable = false;
            e.Cell.ForeColor = System.Drawing.Color.Gray;
            e.Cell.ToolTip = "This date is not available";
        }
    }

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton1.Checked)
        {
            DropDownList4.Items.Clear();
            DropDownList4.Items.Add("<--Select Name-->");
            DropDownList4.Enabled = true;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "SELECT Customer_Id, cname FROM Adv_Booking WHERE Adv_Date=@AdvDate AND check_in = 0";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@AdvDate", Convert.ToDateTime(TextBox1.Text));
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            DropDownList4.Items.Add(dr[0].ToString() + " - " + dr[1].ToString());
                        }
                    }
                }
            }
        }
    }

    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton2.Checked)
        {
            DropDownList4.Items.Clear();
            DropDownList4.Items.Add("<-- New Registration Required -->");
            DropDownList4.Enabled = false;
            DropDownList5.Items.Clear();
            DropDownList6.Items.Clear();
        }
    }

    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RadioButton1.Checked && DropDownList4.SelectedIndex > 0)
        {
            string[] temp = DropDownList4.SelectedItem.Text.Split('-');
            string customerId = temp[0].Trim();

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Fetch Room Type
                string queryRoomType = "SELECT Room_type FROM Adv_Booking WHERE Customer_Id = @CustomerId";
                using (SqlCommand cmd = new SqlCommand(queryRoomType, conn))
                {
                    cmd.Parameters.AddWithValue("@CustomerId", customerId);
                    object roomType = cmd.ExecuteScalar();

                    if (roomType != null)
                    {
                        DropDownList6.Text = roomType.ToString();
                    }
                }

                // Fetch Room Numbers based on Room Type
                DropDownList5.Items.Clear();
                string queryRoomNo = "SELECT Room_No FROM Room_Master WHERE Room_type = @RoomType";
                using (SqlCommand cmd = new SqlCommand(queryRoomNo, conn))
                {
                    cmd.Parameters.AddWithValue("@RoomType", DropDownList6.Text);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            DropDownList5.Items.Add(dr[0].ToString());
                        }
                    }
                }
            }
        }
    }

    protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(DropDownList6.Text))
        {
            DropDownList5.Items.Clear();

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "SELECT room_no FROM Room_Master WHERE room_type = @RoomType";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@RoomType", DropDownList6.Text);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            DropDownList5.Items.Add(dr[0].ToString());
                        }
                    }
                }
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(TextBox1.Text) &&
            !string.IsNullOrEmpty(TextBox2.Text) &&
            DropDownList4.SelectedIndex > 0 &&
            !string.IsNullOrEmpty(DropDownList5.Text) &&
            !string.IsNullOrEmpty(DropDownList6.Text) &&
            !string.IsNullOrEmpty(TextBox4.Text))
        {
            string[] temp = DropDownList4.SelectedItem.Text.Split('-');
            string customerId = temp[0].Trim();
            string checkInTime = DropDownList1.Text + ":" + DropDownList2.Text + " " + DropDownList3.Text;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string insertQuery = "INSERT INTO Chk_In (chk_in_date, chk_in_time, Customer_Id, Room_No, No_of_Days, check_out) " +
                                     "VALUES (@chk_in_date, @chk_in_time, @Customer_Id, @Room_No, @No_of_Days, @check_out)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@chk_in_date", Convert.ToDateTime(TextBox1.Text));
                    cmd.Parameters.AddWithValue("@chk_in_time", checkInTime);
                    cmd.Parameters.AddWithValue("@Customer_Id", customerId);
                    cmd.Parameters.AddWithValue("@Room_No", DropDownList5.Text);
                    cmd.Parameters.AddWithValue("@No_of_Days", TextBox4.Text);
                    cmd.Parameters.AddWithValue("@check_out", "0");
                    cmd.ExecuteNonQuery();
                }

                // Update Adv_Booking
                string updateQuery = "UPDATE Adv_Booking SET check_in = 1 WHERE Customer_Id = @CustomerId AND check_in = 0";
                using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@CustomerId", customerId);
                    cmd.ExecuteNonQuery();
                }
            }

            Response.Redirect("adminhome.aspx");
        }
        else
        {
            Response.Write("<script>alert('Enter necessary information');</script>");
        }
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}

