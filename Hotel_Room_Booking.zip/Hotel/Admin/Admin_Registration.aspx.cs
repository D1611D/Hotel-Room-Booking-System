﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (Session["adminid"] != null)
        {
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand("SELECT max(admin_Id) FROM Admin_Registration", conn);
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                TextBox10.Text = (Convert.ToInt32(dr[0].ToString()) + 1).ToString();
            }
            else
            {
                TextBox10.Text = "1001";
            }
            dr.Close();
            conn.Close();
        }
        else
        {
            Response.Write("<script type=text/javascript>alert('You Must Have To Login...Please Login');</script>");
            Response.Redirect("~/login.aspx");

        }

       // Page.Header.Title = "Admin Registration";
       
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string x1 = "-";

        if (TextBox3.Text != "")
        {
            x1 = TextBox3.Text;
        }



        conn = new SqlConnection(connStr);
        conn.Open();

        cmd = new SqlCommand("INSERT INTO Admin_Registration (admin_Id,admin_name,contact_1,contact_2,addr,email,admin_password,security_que,ans) VALUES(@admin_Id,@admin_name,@contact_1,@contact_2,@addr,@email,@admin_password,@security_que,@ans)", conn);
        cmd.Parameters.AddWithValue("@admin_Id", TextBox10.Text);
        cmd.Parameters.AddWithValue("@admin_name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@contact_1", TextBox2.Text);
        cmd.Parameters.AddWithValue("@contact_2", x1);
        cmd.Parameters.AddWithValue("@addr", TextBox4.Text);
        cmd.Parameters.AddWithValue("@email", TextBox5.Text);
        cmd.Parameters.AddWithValue("@admin_password", TextBox6.Text);
        cmd.Parameters.AddWithValue("@security_que", DropDownList1.Text);
        cmd.Parameters.AddWithValue("@ans", TextBox8.Text);
        
        int rows = cmd.ExecuteNonQuery();

        dr.Close();
        conn.Close();

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox10.Text = "";
        DropDownList1.Text = "";

        Response.Redirect("~/Admin/adminhome.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        //TextBox10.Text = "";
        DropDownList1.SelectedIndex = 0;
    }
}

