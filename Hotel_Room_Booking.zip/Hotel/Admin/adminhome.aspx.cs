﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_adminhome : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminid"] != null)
        {

        }
        else
        {
            Response.Write("<script type=text/javascript>alert('You Must Have To Login...Please Login');</script>");
            Response.Redirect("~/login.aspx");

        }
    }
    protected void adminreg_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_Registration.aspx");
    }
    protected void adminforgetpass_Click(object sender, EventArgs e)
    {
        Response.Redirect("Forget_Pass.aspx");
    }
}