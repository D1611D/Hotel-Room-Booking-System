﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Room_tarrif : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    DataTable dt;
    SqlCommand cmd;
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
      
        if (Session["adminid"] != null)
        {
           
        }
        else
        {
            Response.Write("<script type=text/javascript>alert('You Must Have To Login...Please Login');</script>");
            Response.Redirect("~/login.aspx");

        }

        if (!IsPostBack)
        {
            BindData();
        }
    }
    protected void upload_Click(object sender, EventArgs e)
    {   
       
    }
    protected void BindData()
    {
        con = new SqlConnection(connStr);
        con.Open();
        da = new SqlDataAdapter("select * from Room_Details", con);
        //dt = new DataTable();
       // da.Fill(dt);
       // roomDetails.DataSource = dt;
       // roomDetails.DataBind();
        ds = new DataSet();
        da.Fill(ds);
        roomDetails.DataSource = ds;
        roomDetails.DataBind();

        con.Close();
    }
    // edit event
    protected void roomDetails_RowEditing(object sender, GridViewEditEventArgs e)
    {
        roomDetails.EditIndex = e.NewEditIndex;
        BindData();

    }
    // update event
    protected void roomDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
      
        string id = roomDetails.DataKeys[e.RowIndex].Value.ToString();
        GridViewRow gv = roomDetails.Rows[e.RowIndex];

        string rname = ((TextBox)(gv.Cells[1].Controls[0])).Text;
        string rtype = ((TextBox)(gv.Cells[2].Controls[0])).Text;
        string bed = ((TextBox)(gv.Cells[3].Controls[0])).Text;
        string price = ((TextBox)(gv.Cells[4].Controls[0])).Text;

        con = new SqlConnection(connStr);
        con.Open();
        SqlCommand cmd = new SqlCommand("update Room_Details set room_name='" + rname + "',room_type='" + rtype + "',bed='" + bed + "',price=" + price + " where id=" + id + "", con);
        cmd.ExecuteNonQuery();
        con.Close();
        //Response.Write(oldid+","+rname+","+rtype+","+bed+","+price+","+newid);
        roomDetails.EditIndex = -1;
        BindData();



    }
    // cancel edit event
    protected void roomDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        roomDetails.EditIndex = -1;
        BindData();
    }
    //delete event
    protected void roomDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //GridViewRow row = (GridViewRow)roomDetails.Rows[e.RowIndex];
        string id = roomDetails.DataKeys[e.RowIndex].Value.ToString();
        con = new SqlConnection(connStr);
        con.Open();
        SqlCommand cmd = new SqlCommand("delete FROM Room_Details where id='" + id + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
      
        BindData();

    }



    protected void Add_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddRoomType.aspx");

    }
  
}