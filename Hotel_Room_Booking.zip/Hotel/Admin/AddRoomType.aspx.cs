﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddRoomType : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter da;
    DataSet ds;
    DataTable dt;
    SqlCommand cmd;
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminid"] != null)
        {

        }
        else
        {
            Response.Write("<script type=text/javascript>alert('You Must Have To Login...Please Login');</script>");
            Response.Redirect("~/login.aspx");

        }

       
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string name = txtName.Text;
        string type = txtType.Text;
        string bed = txtBed.Text;
        string price = txtPrice.Text;

       
            con = new SqlConnection(connStr);
            con.Open();
            cmd = new SqlCommand("insert into Room_Details(room_name,room_type,bed,price) VALUES (@room_name, @room_type, @bed, @price)", con);
            cmd.Parameters.AddWithValue("@room_name", name);
            cmd.Parameters.AddWithValue("@room_type", type);
            cmd.Parameters.AddWithValue("@bed", bed);
            cmd.Parameters.AddWithValue("@price", price);

            cmd.ExecuteNonQuery();

            txtName.Text = "";
            txtType.Text = "";
            txtBed.Text = "";
            txtPrice.Text = "";
            Response.Redirect("Room_tarrif.aspx");
            // BindData();

      
    }
    
    
}