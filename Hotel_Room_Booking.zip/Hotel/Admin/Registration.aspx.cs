﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (Session["adminid"] != null)
        {
            conn = new SqlConnection(connStr);
            conn.Open();
            cmd = new SqlCommand("SELECT max(Customer_Id) FROM Registration", conn);
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                TextBox10.Text = (Convert.ToInt32(dr[0].ToString()) + 1).ToString();
            }
            dr.Close();
            conn.Close();
        }

        else
        {
            Response.Write("<script type=text/javascript>alert('You Must Have To Login...Please Login');</script>");
            Response.Redirect("~/login.aspx");

        }

        //Page.Header.Title = "Registration";
        
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string x1 = "-";
        string x2 = "-";

        if (TextBox3.Text != "")
        {
            x1 = TextBox3.Text;
        }

        //conn = new SqlConnection(@"Data Source=WELCOME-PC;Initial Catalog=hotelmanagement;Integrated Security=True");
        conn = new SqlConnection(connStr);
        conn.Open();

        cmd = new SqlCommand("INSERT INTO Registration (Customer_Id,cname,contact_1,contact_2,addr,email,cpassword,security_que,ans) VALUES(@Customer_Id,@cname,@contact_1,@contact_2,@addr,@email,@cpassword,@security_que,@ans)", conn);
        cmd.Parameters.AddWithValue("@Customer_Id", TextBox10.Text);
        cmd.Parameters.AddWithValue("@cname", TextBox1.Text);
        cmd.Parameters.AddWithValue("@contact_1", TextBox2.Text);
        cmd.Parameters.AddWithValue("@contact_2", x1);
        cmd.Parameters.AddWithValue("@addr", TextBox4.Text);
        cmd.Parameters.AddWithValue("@email", TextBox5.Text);
        cmd.Parameters.AddWithValue("@cpassword", TextBox6.Text);
        cmd.Parameters.AddWithValue("@security_que", DropDownList1.Text);
        cmd.Parameters.AddWithValue("@ans", TextBox8.Text);
        //cmd.Parameters.AddWithValue("@ref", x2);

        int rows = cmd.ExecuteNonQuery();

        dr.Close();
        conn.Close();

        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
       
        TextBox10.Text = "";
        DropDownList1.Text = "";
        Response.Redirect("~/Admin/Check_in.aspx");
    }
}

