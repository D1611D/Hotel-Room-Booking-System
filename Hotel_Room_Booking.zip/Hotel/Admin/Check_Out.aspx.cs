﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Check_Out : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
    string t2 = ""; //cu_id
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["adminid"] != null)
        {
            TextBox3.Text = Session["adminnm"].ToString();
        }
        else
        {
            Response.Write("<script type=text/javascript>alert('You Must Have To Login...Please Login');</script>");
            Response.Redirect("~/login.aspx");

        }

        //DateTime.Now.ToString("HH:mm:ss tt");

        //Page.Header.Title="Check Out";
        //Display current LONG date in textbox
        if (!Page.IsPostBack)
        {
            TextBox10.Text = DateTime.Now.ToString("D");
        }
        //this code is for HOUR dropdown list
        int h1 = Convert.ToInt32(DateTime.Now.ToString("HH"));
        if (h1 > 12)
            h1 = h1 - 12;

        DropDownList1.Text = h1.ToString();


        //this code is for MINUTE dropdown list
        for (int i = 1; i <= 59; i++)
        {
            DropDownList2.Items.Add(i.ToString());
        }
        DropDownList2.Text = Convert.ToInt32(DateTime.Now.ToString("mm")).ToString();

        //this code is for SECOND dropdown list
        DropDownList3.Text = DateTime.Now.ToString("tt");
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox10.Text = Calendar1.SelectedDate.ToString("D");
    }

    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date < System.DateTime.Today)
        {
            // Disable date
            e.Day.IsSelectable = false;
            // Change color of disabled date
            e.Cell.ForeColor = System.Drawing.Color.Gray;
            e.Cell.ToolTip = "This date is not available";
        } 

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        DropDownList4.Items.Clear();
        DropDownList4.Items.Add("<--Select-->");
            //2 add room type to dropdown
        conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand("SELECT Room_No FROM Chk_In WHERE check_out=0 ORDER BY Room_No", conn);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                DropDownList4.Items.Add(dr[0].ToString());
            }
            dr.Close();
            conn.Close();

    }
    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {
        string t1="";
        string t3_cn="";
        string t4_rt = "";

        if (DropDownList4.Text != "<--Select-->")
        {
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand("SELECT chk_in_date,Customer_Id FROM Chk_In WHERE Room_No = '"+DropDownList4.Text+"' AND check_out=0", conn);
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                t1 = dr[0].ToString();
                t2 = dr[1].ToString();
            }
            dr.Close();
            conn.Close();

            TextBox7.Text = t1.ToString();

            //4 no of days
            DateTime dt1 = DateTime.Parse(TextBox7.Text); //check in date
            DateTime dt2 = DateTime.Parse(TextBox10.Text); // check out date
            TimeSpan ts = dt2 - dt1;
            int days = ts.Days;
            if (days == 0)
            {
                days = 1;
            }
            else if (Convert.ToInt32(DropDownList1.Text) >= 3 && DropDownList3.Text == "PM")
            {
                days++;
            }
            TextBox4.Text = days.ToString(); // no. of days

            //customer name

            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand("SELECT cname FROM Registration WHERE Customer_Id='"+ t2 +"'", conn);
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                t3_cn = dr[0].ToString();
                TextBox1.Text = t3_cn;
            }
            dr.Close();
            conn.Close();


            //room type and tarrif
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand("SELECT room_tariff FROM Room_Master WHERE room_no='" + DropDownList4.Text + "'", conn);
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                t4_rt = dr[0].ToString();
                TextBox8.Text = t4_rt;
            }
            dr.Close();
            conn.Close();

            TextBox2.Text = (Convert.ToInt32(t4_rt) *Convert.ToInt32(TextBox4.Text)).ToString(); //total

            TextBox6.Text = (Convert.ToInt32(TextBox2.Text) + Convert.ToInt32(TextBox2.Text) * 0.12).ToString();//Amount
            TextBox11.Text = (Convert.ToInt32(TextBox2.Text) + Convert.ToInt32(TextBox2.Text) * 0.12 - Convert.ToInt32(TextBox9.Text)).ToString();//final amount

            Button1.Enabled = true;
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text != "" && TextBox4.Text != "" && TextBox8.Text != "" && TextBox9.Text != "")
        {
            TextBox6.Text = (Convert.ToInt32(TextBox2.Text) + Convert.ToInt32(TextBox2.Text) * 0.12).ToString();//Amount
            TextBox11.Text = (Convert.ToInt32(TextBox2.Text) + Convert.ToInt32(TextBox2.Text) * 0.12 - Convert.ToInt32(TextBox9.Text)).ToString();
        }
        else 
        {
            Response.Write("<script type=text/javascript>alert('Enter necessary information');</script>");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //only for customer id
        conn = new SqlConnection(connStr);
        conn.Open();

        cmd = new SqlCommand("SELECT Customer_Id FROM Chk_In WHERE Room_No = '" + DropDownList4.Text + "' AND check_out=0", conn);
        dr = cmd.ExecuteReader();

        if (dr.Read())
        {
            t2 = dr[0].ToString();
        }
        dr.Close();
        conn.Close();
        //customer id over

        string temp1;
        temp1 = DropDownList1.Text + ":" + DropDownList2.Text + " " + DropDownList3.Text;

        conn = new SqlConnection(connStr);
        conn.Open();

        cmd = new SqlCommand("INSERT INTO Chk_out (chk_out_date,chk_out_time,Customer_Id,noofdays,total,tax,dis,amount) VALUES(@chk_out_date,@chk_out_time,@Customer_Id,@noofdays,@total,@tax,@dis,@amount)", conn);
        cmd.Parameters.AddWithValue("@chk_out_date", Convert.ToDateTime(TextBox10.Text));
        cmd.Parameters.AddWithValue("@chk_out_time", temp1);
        cmd.Parameters.AddWithValue("@Customer_Id", t2);
        cmd.Parameters.AddWithValue("@noofdays", Convert.ToInt32(TextBox4.Text));
        cmd.Parameters.AddWithValue("@total",Convert.ToInt32(TextBox2.Text));
        cmd.Parameters.AddWithValue("@tax",Convert.ToInt32("12"));
        cmd.Parameters.AddWithValue("@dis", Convert.ToInt32(TextBox9.Text));
        cmd.Parameters.AddWithValue("@amount", Convert.ToInt32(TextBox11.Text));

        int rows = cmd.ExecuteNonQuery();
        conn.Close();


        //4 update chk_in table
        conn = new SqlConnection(connStr);
        conn.Open();

        cmd = new SqlCommand("UPDATE Chk_In SET check_out='1' WHERE Customer_Id = '" + t2 + "' AND check_out = '0'", conn);

        int rows1 = cmd.ExecuteNonQuery();
        conn.Close();

        DropDownList4.Items.Clear();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox4.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox9.Text = "";
        TextBox11.Text = "";

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        DropDownList4.Items.Clear();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox4.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox9.Text = "";
        TextBox11.Text = "";
    }
}
