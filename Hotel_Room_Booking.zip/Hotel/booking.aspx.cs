﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class booking : System.Web.UI.Page
{
    SqlConnection conn, conn1;
    SqlCommand cmd, cmd1;
    SqlDataReader dr, dr1;
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
      
        //4 cid and name automatically from session
        
       if (Session["cid"] != null)
        {
            Label1.Visible = true;
            Label13.Visible = true;
            Label14.Visible = true;

            TextBox1.Visible = true;
            TextBox2.Visible = true;

            Label12.Text = "Customer Name";
            DropDownList2.Visible = false;

            TextBox1.Text = Session["cid"].ToString();
            TextBox2.Text = Session["cnm"].ToString();
            TextBox1.ReadOnly = true;
            TextBox2.ReadOnly = true;
        }
        else
        {
            Session["wronglongin"] = "yes";
            Response.Write("<script type='text/javascript'>alert('You Must Have to Login First..');</script>");
            Response.Redirect("login.aspx");
        }

        if (!Page.IsPostBack)
        {
            //Page.Header.Title = "Advance Booking";


            //2 add room type to dropdown
            conn = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=hotel;Integrated Security=True");
            conn.Open();

            cmd = new SqlCommand("SELECT DISTINCT room_type FROM Room_Master", conn);
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                DropDownList1.Items.Add(dr[0].ToString());
            }
            dr.Close();
            conn.Close();
        }

        TextBox3.Text = DateTime.Now.ToString("D");
    }
    


    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox3.Text = Calendar1.SelectedDate.ToString("D");
    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date < System.DateTime.Today)
        {
            // Disable date
            e.Day.IsSelectable = false;
            // Change color of disabled date
            e.Cell.ForeColor = System.Drawing.Color.Gray;
            e.Cell.ToolTip = "This date is not available";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         string []temp = new string[2];
        if (DropDownList2.Visible == true)
        {
            temp = ((DropDownList2.Text).Split('-'));
        }
        else if (TextBox1.Visible == true)
        {
            temp[0] = TextBox1.Text;
            temp[1] = TextBox2.Text;
        }

        conn = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=hotel;Integrated Security=True");
        conn.Open();

        //cmd = new SqlCommand("INSERT INTO Registration (Customer_Id,cname,contact_1,contact_2,addr,email,cpassword,security_que,ans,ref) VALUES(@Customer_Id,@cname,@contact_1,@contact_2,@addr,@email,@cpassword,@security_que,@ans,@ref)", conn);
        cmd = new SqlCommand("INSERT INTO Adv_Booking(Customer_Id,cname,Adv_Date,Room_type,No_of_rooms,No_of_days,check_in) values(@Customer_Id,@cname,@Adv_Date,@Room_type,@No_of_rooms,@No_of_days,@check_in)", conn);

        cmd.Parameters.AddWithValue("@Customer_Id", temp[0].Trim());
        cmd.Parameters.AddWithValue("@cname", temp[1].Trim());
        cmd.Parameters.AddWithValue("@Adv_Date",Convert.ToDateTime(TextBox3.Text));
        cmd.Parameters.AddWithValue("@Room_type",DropDownList1.Text);
        cmd.Parameters.AddWithValue("@No_of_rooms",TextBox4.Text);
        cmd.Parameters.AddWithValue("@No_of_days",TextBox5.Text);
        cmd.Parameters.AddWithValue("@check_in", "0");

        int rows = cmd.ExecuteNonQuery();
        conn.Close();
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";

        DropDownList1.Text = "Delux";
        Button1.Enabled = false;
        lblbook.Visible = true;
        lbl1.Visible = false;
        lblbook.Text = "Thankyou, Your Room has Been Booked...!!";
       
    }
    
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox3.Text = DateTime.Now.ToString("D");
        TextBox5.Text = "1";
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        if (TextBox3.Text != "" && TextBox4.Text != "" && TextBox5.Text != "")
        {
            int totroom = 0, availableroom = 0, bookedroom = 0, r = 0;

            conn1 = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=hotel;Integrated Security=True");
            conn1.Open();

            cmd1 = new SqlCommand("SELECT count(Room_type) FROM Room_Master where room_type ='" + DropDownList1.Text + "'", conn1);
            dr1 = cmd1.ExecuteReader();

            if (dr1.Read())
            {
                totroom = Convert.ToInt32(dr1[0].ToString());
            }
            //dr1.Close();

            conn = new SqlConnection(@"Data Source=DESKTOP-QLM3ODR\MSSQLSERVER2;Initial Catalog=hotel;Integrated Security=True");
            conn.Open();

            cmd = new SqlCommand("SELECT count(Room_type) FROM Adv_Booking where Adv_Date='" + Convert.ToDateTime(TextBox3.Text) + "' AND Room_type ='" + DropDownList1.Text + "'", conn);
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                bookedroom = Convert.ToInt32(dr[0]);
                availableroom = totroom - bookedroom;
            }

            r = Convert.ToInt32(TextBox4.Text);

            if (availableroom >= r)
            {
                Button1.Enabled = true;
                lbl1.Visible = true;
                lbl1.Text = "Rooms Available";
            }
            else
            {
                Button1.Enabled = false;
                lbl1.Visible = true;
                lbl1.Text = "Sorry, Rooms are NOT Available";
            }
            dr.Close();
            conn.Close();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('Enter necessary information');</script>");
        }
    }
}