﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Forget_Pass : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        //4 title of the page
        //Page.Header.Title = "Forgot Password";
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //get question
        conn = new SqlConnection(connStr);
        conn.Open();

        cmd = new SqlCommand("SELECT security_Que FROM Registration where email = '" + TextBox1.Text + "'", conn);
        dr = cmd.ExecuteReader();

        if (dr.Read())
        {
            TextBox2.Text = dr[0].ToString();
        }
        else
        {
            Response.Write("<script type=text/javascript>alert('Invalid Username or Password');</script>");
        }
        dr.Close();
        conn.Close();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "")
        {
            //get password
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand("SELECT cpassword FROM Registration where email = '" + TextBox1.Text + "' AND security_que ='" + TextBox2.Text + "' AND ans = '" + TextBox3.Text + "'", conn);
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                TextBox4.Text = dr[0].ToString();
            }
            else
            {
                Response.Write("<script type=text/javascript>alert('Invalid Information');</script>");
                TextBox4.Text = "";
            }
            dr.Close();
            conn.Close();
            Button4.Visible = true;


        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}