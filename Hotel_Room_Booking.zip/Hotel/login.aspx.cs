﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    SqlConnection conn;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlCommand cmd2;
    string connStr = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        //Page.Header.Title = "Login";

        //wrong login

        //if (Session["wronglongin"] == null)
        //{
        //    lbl1.Visible = false;
        //}
        //else
        //{
        //    lbl1.Visible = true;
        //}
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        conn = new SqlConnection(connStr);
        conn.Open();

        cmd = new SqlCommand("SELECT Customer_Id,cname,email,cpassword FROM Registration where email = '" + TextBox1.Text + "' AND cpassword ='" + TextBox2.Text + "'", conn);

        cmd2 = new SqlCommand("SELECT admin_Id,admin_name,email,admin_password FROM Admin_Registration where email = '" + TextBox1.Text + "' AND admin_password ='" + TextBox2.Text + "'", conn);

        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Session["cid"] = dr["Customer_Id"];
            Session["cnm"] = dr["cname"];
            Session["wronglongin"] = null;

            Response.Write("<script type=text/javascript>alert('Successfully loging');</script>");

            Response.Redirect("booking.aspx");

        }
        dr.Close();
        dr = cmd2.ExecuteReader();


        if (dr.Read())
        {
            Session["adminid"] = dr["admin_Id"];
            Session["adminnm"] = dr["admin_name"];
            Session["wronglongin"] = null;

            Response.Write("<script type=text/javascript>alert('Successfully loning');</script>");

            Response.Redirect("Admin/Check_in.aspx");
        }
        else
        {
            Response.Write("<script type=text/javascript>alert('Invalid Username or Password');</script>");
        }

        dr.Close();
        conn.Close();
        TextBox1.Focus();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
}